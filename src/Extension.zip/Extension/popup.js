document.getElementById("addCompany").addEventListener("click", () => {
  const companyName = document.getElementById("companyName").value;
  if (companyName) {
    addCompanyToDB(companyName);
    document.getElementById("companyName").value = "";
  }
});

function addCompanyToDB(companyName) {
  // Example function to add a company to local storage
  chrome.storage.local.get(["companies"], (result) => {
    const companies = result.companies || [];
    companies.push(companyName);
    chrome.storage.local.set({ companies });
    displayCompanies(companies);
  });
}

function displayCompanies(companies) {
  const contactList = document.getElementById("contactList");
  contactList.innerHTML = "";
  companies.forEach((company) => {
    const li = document.createElement("li");
    li.textContent = company;
    contactList.appendChild(li);
  });
}

// Load companies on popup open
chrome.storage.local.get(["companies"], (result) => {
  console.log(result.companies, "Sdfsdfsdfsdfsdfsdf")
  displayCompanies(result.companies || []);
});
