function saveContact(contact) {
  chrome.storage.local.get(['contacts'], (result) => {
      const contacts = result.contacts || [];
      contacts.push(contact);
      chrome.storage.local.set({ contacts });
  });
}