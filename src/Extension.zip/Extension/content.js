const projectDetails = document.querySelector(".project-details");
if (projectDetails) {
  const contactList = document.createElement("div");
  contactList.innerHTML = `<h3>Contacts</h3><ul id="projectContacts"></ul>`;
  projectDetails.appendChild(contactList);

  // Fetch and display contacts related to the project
  fetchContactsForProject();

  function fetchContactsForProject() {
    // Placeholder for fetching contacts from your database
    chrome.storage.local.get(["contacts"], (result) => {
      const contacts = result.contacts || [];
      const projectContacts = document.getElementById("projectContacts");
      contacts.forEach((contact) => {
        const li = document.createElement("li");
        li.textContent = contact.name; // Assuming contact has a name property
        projectContacts.appendChild(li);
      });
    });
  }
}
