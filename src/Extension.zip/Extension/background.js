chrome.runtime.onInstalled.addListener(() => {
  console.log("CRM Extension Installed");
});
