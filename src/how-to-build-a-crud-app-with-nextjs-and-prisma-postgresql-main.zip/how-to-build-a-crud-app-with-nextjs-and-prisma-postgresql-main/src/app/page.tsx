import Image from 'next/image'
import PostPage from './(route)/post/page'

export default function Home() {
  return (
   <PostPage />
  )
}
